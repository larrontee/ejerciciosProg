import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class RecorridoStax {
    public static void main(String[] args) {
        try {
            XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
            XMLEventReader xmlReader = xmlInputFactory.createXMLEventReader(new FileInputStream("Biblioteca.xml"));

            int contadorpags=0;
            String librocorto = "";

            while (xmlReader.hasNext()){
                XMLEvent xmlEvent= xmlReader.nextEvent();
                if (xmlEvent.isStartElement()){
                    StartElement startElement=xmlEvent.asStartElement();
                    if (startElement.getName().getLocalPart().equals("titulo")){
                        System.out.println();
                    }
                }
                if (xmlEvent.isCharacters()){
                    Characters characters=xmlEvent.asCharacters();

                }
            }

            System.out.println("El libro con menos paginas es: "+librocorto);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
